
#ifndef PDE_H_DEFINED
#define PDE_H_DEFINED


#define LAPLACE 0
#define DIRICHLET 0
#define INTERIOR_MODE 0
#define FACTOR 2.0	//	the factor for epsilon = factor * h	//
#define REG_MODE 1	//	to use regularized partial or not	//
#define POLY_TEST 0	//	test polynomial weight
#define SINE_TEST 1	//	test sine weight
#define TRAD_ONESIDED 0	//	onesided tubular region for traditional way	//
#define COMBO_ONESIDED 0//	onesided tubular region for combo way	//

#define DIST_FILEMODE 0	//	Reading distance function from file	//
#define BOUNDARY_UTEST 0//	Test solutions on boundary	//
#define TEST_SINGLE_LAYER 1//	Test solving with single layer formulation	//

#define TAU_FACTOR 0.5	//	Regularization
#define COMBO 1

#endif
