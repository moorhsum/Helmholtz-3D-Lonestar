clear all;
close all;

FASTMODE = 0;
POLY_TEST = 0;
SINE_TEST = 1;
REGULAR_TEST = 1;


if (FASTMODE == 1)
    msg = sprintf('Computing condition number in fast mode.\n');
else
    msg = sprintf('Computing condition number in regular mode\n');
end
disp(msg);


if (POLY_TEST == 1)
    Polyreal = load('Poly.txt');
    Polyimg = load('Polyimg.txt');
    Poly = Polyreal + Polyimg * i;
    
    tic;
    if (FASTMODE == 1)
        Polycond = condest(Poly);
    else
        Polycond = cond(Poly);
    end
    toc;
    
    msg = sprintf('condition number of Poly = %.4E\n', Polycond);
    disp(msg);
    clear Polyreal Polyimg Poly;
end


if (SINE_TEST == 1)
    Sinereal = load('Sine.txt');
    Sineimg = load('Sineimg.txt');
    Sine = Sinereal + Sineimg * i;
   
    tic;
    if (FASTMODE == 1)
        Sinecond = condest(Sine);
    else
        Sinecond = cond(Sine);
    end
    toc;
    
    msg = sprintf('condition number of Sine = %.4E\n', Sinecond );
    disp(msg);
    clear Sinereal Sineimg Sine;
end


if (REGULAR_TEST == 1)
    
    breal = load('b.txt');
    bimg = load('bimg.txt');
 
    Creal = load('testC.txt');
    Cimg = load('testCimg.txt');
    b = breal + bimg * i;
    C = Creal + Cimg * i;
    
    tic;
    if (FASTMODE == 1)
        Ccond = condest(C);
    else
        Ccond = cond(C);
    end
    toc;
    
    msg = sprintf('condition number of C = %.4E\n', Ccond );
    disp(msg);
    clear Creal Cimg C b bimg breal;
end

 

% xreal = load('x.txt');
% ximg = load('ximg.txt');


% x = xreal + ximg * i;

% matlabx = A\b


% errorx = abs(x - matlabx);% ./abs(matlabx);
% result = A*x;
% errorb = abs(result-b);% ./abs(b);




% size(b)
% msg = sprintf('condition number of Sine = %.4E\n', cond(Sine) );
% disp(msg);
% msg = sprintf('condition number of Original = %.4E\n', cond(C) );
% disp(msg);
% msg = sprintf('Size of original %d, Size of new %d.\n', length(C), length(b));
% disp(msg);



%size(C)
% cond(C)

% norm(errorx)/norm(matlabx)
% norm(errorb)/norm(b)