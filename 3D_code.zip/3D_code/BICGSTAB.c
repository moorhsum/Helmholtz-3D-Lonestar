
#include "BICGSTAB.h"


int CompBiCG(int size, double *density, double *densityimg, double **Kernel, double **Kernelimg, double *b, double *bimg)
{
	FILE *fp3Dx, *fprealb, *fp3Dximg, *fpimgb;
	FILE *fpverifyb, *fpverifybimg;
	FILE *fp3DC;		//	DEBUG	//	
	FILE *fp3DCimg;		//	DEBUG	//

	int compsize = 2 * size;
	double nonhomogeneous = 0.0;
	double nonhomogeneousimg = 0.0;
	double zx, zy;
	double zstarx[size], zstary[size];
//	double epsilon = FACTOR * h;
	int count = 0;;

	double tempC[2];
//	double r[size], rhat[size], x[size], v[size], p[size], s[size], t[size];
//	double rimg[size], rhatimg[size], ximg[size], vimg[size], pimg[size], simg[size], timg[size];
	double x[size], ximg[size], xtilde[size], xtildeimg[size], r[size], rimg[size], rtilde[size], rtildeimg[size];
	double p[size], pimg[size], ptilde[size], ptildeimg[size], pold[size], poldimg[size], ptildeold[size], ptildeoldimg[size];
	double Akp[size], Akpimg[size], Akptilde[size], Akptildeimg[size];

//	double b[3] = TESTB;
//	double bimg[3] = TESTBIMG;
//	double b[size], bimg[size];

	double error[size], errorimg[size];
	double alpha = 1.0, rhoi = 1.0, rhoi1 = 1.0, omega = 1.0;
	double alphaimg = 0.0, rhoiimg = 0.0, rhoi1img = 0.0, omegaimg = 0.0;
	double beta, betaimg;
	double errornorm, preerrornorm;
	double comptemp, comptempnum, comptempnumimg, comptempden, comptempa, comptempb, comptempc, comptempd;
	double innerrold, innerroldimg;

	double sum = 0.0, regsum = 0.0, sumimg = 0.0, regsumimg = 0.0;
	double normb = 0.0;
	double BC_sum = 0.0;		//	for zero BC	//
	double accpower;
	double accuracy = DEFAULTACC;

	int countrun = 0;
	int checksize, checksizeimg;

	char denfilename[50], denimgfilename[50];

//	static int flag = 0;

	time_t loop_initime, loop_endtime, seconds;

	if (INTERACTIVE_ACCURACY == 1)
	{
		printf("Enter the accuracy in 10^x ( 0 > x > -10)\n");
		scanf("%lf", &accpower);
		if ( (accpower > -10.0) && (accpower < 0.0) )
			accuracy = pow(10, accpower);
	}

	printf("Using accuracy = %.8E.\n", accuracy);

	//	INITIALIZING THE THINGS NEEDED FOR BICONJUGATE GRADIENT STABILIZED	//
////////////////////////////////////////////////////////////////////////////
//	TESTB;	
//	bimg[3] = TESTBIMG;

//	fprintf(fpverifyb, "%d\n", size);
//	fprintf(fpverifybimg, "%d\n", size);
//	for (int i = 0; i < size ; i++)
//	{
//		fprintf(fpverifyb, "%lf ", b[i]);
//		fprintf(fpverifybimg, "%lf ", bimg[i]);
//	}
////////////////////////////////////////////////////////////////////////////


	normb = sqrt(inner(size, b, b) + inner(size, bimg, bimg));
	printf("b norm is %lf\n", normb);

	for (int counter = 0; counter < size; counter++)
	{
		x[counter] = 0.0;
		ximg[counter] = 0.0;
		r[counter] = b[counter];
		rimg[counter] = bimg[counter];
		p[counter] = r[counter];
		pimg[counter] = rimg[counter];

		rtilde[counter] = r[counter];
		rtildeimg[counter] = (-1.0)*rimg[counter];
		ptilde[counter] = rtilde[counter];
		ptildeimg[counter] = rtildeimg[counter];

		if ( (rtilde[counter] != rtilde[counter]) || (rtildeimg[counter] != rtildeimg[counter]) )
		{
			printf("counter = %d.\n, rtilde = %lf, r = %lf.\n", counter, rtilde[counter], r[counter]);
			printf("rtildeimg = %lf, rimg = %lf.\n", rtildeimg[counter], rimg[counter]);
		}
	}
	//	(r, r^)	//
	innerrold = inner(size, r, rtilde) + inner(size, rimg, rtildeimg);
	innerroldimg = inner(size, rimg, rtilde) - inner(size, r, rtildeimg);

	///////////////////////////////////////////////////////////////////////////////////////


	for (int i = 0; i < size; i++)
	{
		BC_sum += fabs(r[i]);
		BC_sum += fabs(rimg[i]);
	}
	if ( BC_sum < pow(10,-13.0))	//	for zero BC	//
	{
		printf("Here.\n");
		r[0] = 0.000000001;
		rimg[0] = 0.000000001;
		rtilde[0] = 0.000000001;
		rtildeimg[0] = 0.000000001;
	}

	if ( BC_sum < pow(10, -15.0) )
	{
		printf("Zero BC.\n");
		for (int i = 0; i < size; i++)
		{
			density[i] = 0.;
			densityimg[i] = 0.;
		}
		return 0;
	}


	for (int i = 1; i <= 200; i++)
	{
		loop_initime = time(NULL);

		//////	FIRST MATRIX MULTIPLICATION	////////////
		for (int j = 0; j < size; j++)
		{
			sum = 0.0;
			sumimg = 0.0;
			for (int k = 0; k < size; k++)
			{
				sum += (Kernel[j][k] * p[k] - Kernelimg[j][k] * pimg[k]);		//	A * p	//
				sumimg += (Kernel[j][k] * pimg[k] + Kernelimg[j][k] * p[k]);	//	A * p	//
			}
			Akp[j] = sum;				//	v = A * p	//
			Akpimg[j] = sumimg;

			if ((Akp[j] != Akp[j])||(Akp[j] +1 == Akp[j])||(Akpimg[j] != Akpimg[j])||(Akpimg[j]+1==Akpimg[j]))
			{
				printf("Akp wrong, j = %d, Akp[j] = %lf, Akpimg[j] = %lf.\n", j, Akp[j], Akpimg[j]);
				exit(0);
			}
//			printf("v[%d] = %.15lf\n", j, v[j]);
		}
		loop_endtime = time(NULL);
		seconds = loop_endtime - loop_initime;

//		if (i == 1)
//			printf("Made to 1st. Took %ld minutes %ld seconds.\n", seconds/60, seconds % 60);
		/////	FIRST MATRIX MULTIPLICATION ENDS	////


		//////	SECOND MATRIX MULTIPLICATION	/////////////
		for (int j = 0; j < size; j++)
		{
			sum = 0.0;
			sumimg = 0.0;
			for (int k = 0; k < size; k++)
			{
				sum += (Kernel[k][j]*ptilde[k] + Kernelimg[k][j]*ptildeimg[k]);
				sumimg += (Kernel[k][j]*ptildeimg[k] - Kernelimg[k][j]*ptilde[k]);
			}
			Akptilde[j] = sum;				//	Akptilde = A^H * p		//
			Akptildeimg[j] = sumimg;
			if ((Akptilde[j]!=Akptilde[j])||(Akptildeimg[j]!=Akptildeimg[j]))
			{
				printf("Akptilde wrong, j = %d, Akptilde[j] = %lf, Akptildeimg[j] = %lf.\n", j, Akptilde[j], Akptildeimg[j]);
				printf("alpha = %lf, r[%d] = %lf.\n", alpha, j, r[j]);
				exit(0);
			}
		}
		///////	SECOND MATRIX MULTIPLICATION ENDS	//////


		//	DEFINE IF A = a+bi, B = c+di, then (A,B) = sigma(A*B') = (a+bi)dot(c-di)	//
		//	THAT IS, CONJUGATE THE LATTER VECTOR	//

		comptempa = inner(size, r,rtilde) + inner(size, rimg, rtildeimg);
		comptempb = inner(size, rimg,rtilde) - inner(size, r, rtildeimg);
		comptempc = inner(size, Akp, ptilde) + inner(size, Akpimg, ptildeimg);
		comptempd = inner(size, Akpimg, ptilde) - inner(size, Akp, ptildeimg);
		comptempnum = comptempa*comptempc + comptempb*comptempd;
		comptempnumimg = comptempb*comptempc - comptempa*comptempd;
		comptempden = comptempc*comptempc + comptempd*comptempd;
		alpha = comptempnum/comptempden;
		alphaimg = comptempnumimg/comptempden;

		for (int j = 0; j < size; j++)
		{
			x[j] = x[j] + alpha * p[j] - alphaimg * pimg[j];
			ximg[j] = ximg[j] + alphaimg * p[j] + alpha * pimg[j];
			r[j] = r[j] - alpha * Akp[j] + alphaimg * Akpimg[j];
			rimg[j] = rimg[j] - alphaimg * Akp[j] - alpha * Akpimg[j];

			rtilde[j] = rtilde[j] - alpha * Akptilde[j] - alphaimg * Akptildeimg[j];
			rtildeimg[j] = rtildeimg[j] + alphaimg * Akptilde[j] - alpha * Akptildeimg[j];
//			if ( (p[j] != p[j])|| (p[j] + 1.0 ==p[j]) )
//				printf("j = %d, r[j] = %lf, v[j] = %lf, beta = %lf.\n", j, r[j], v[j], beta);
		}


		//	BEGIN beta = (r^,r)_k+1/(r^, r)k		//
		comptempc = innerrold;
		comptempd = innerroldimg;	
		comptempa = inner(size, r, rtilde) + inner(size, rimg, rtildeimg);
		comptempb = inner(size, rimg, rtilde) - inner(size, r, rtildeimg);
		comptempnum = comptempa*comptempc + comptempb*comptempd;
		comptempnumimg = comptempb*comptempc - comptempa*comptempd;
		comptempden = comptempc*comptempc + comptempd*comptempd;
		beta = comptempnum/comptempden;
		betaimg = comptempnumimg/comptempden;

		innerrold = comptempa;
		innerroldimg = comptempb;

		//	END a = rho/ (r^, v)	//

		for (int j = 0; j < size; j++)		
		{
			pold[j] = p[j];
			poldimg[j] = pimg[j];
			ptildeold[j] = ptilde[j];
			ptildeoldimg[j] = ptildeimg[j];
		}

		for (int j = 0; j < size; j++)
		{
			p[j] = r[j] + beta * pold[j] - betaimg * poldimg[j];		//	p = r + beta * p	//
			pimg[j] = rimg[j] + betaimg * pold[j] + beta * poldimg[j];

			ptilde[j] = rtilde[j] + beta * ptildeold[j] + betaimg * ptildeoldimg[j];
			ptildeimg[j] = rtildeimg[j] - betaimg * ptildeold[j] + beta * ptildeoldimg[j];


			if ((p[j] !=p[j])||(p[j] + 1 ==p[j])||(pimg[j] !=pimg[j])||(pimg[j]+1==pimg[j]))
			{
				printf("s wrong, j = %d, alpha = %lf, r[j] = %lf, rimg[j] = %lf.\n", j, alpha, r[j], rimg[j]);
				exit(0);
			}
		}



		preerrornorm = errornorm;
		errornorm = sqrt(inner(size, r, r) + inner(size, rimg, rimg))/normb;
//		printf("Run %d, error = %.8E\n", i, errornorm);


		loop_endtime = time(NULL);
		seconds = loop_endtime - loop_initime;
//		if (i == 1)
//			printf("This run took %ld minutes and %ld seconds.\n", seconds/60, seconds % 60);
		countrun++;

		if (errornorm < accuracy)
			break;
		if (errornorm != errornorm)
			break;
		if (fabs(preerrornorm - errornorm) < pow(10, -3) * accuracy)
			break;
		
	}

	printf("After %d runs, the error is %.10E.\n", countrun, errornorm);
	
	for (int i = 0; i < size; i++)
	{
		density[i] = x[i];
		densityimg[i] = ximg[i];
	}
	
	return 0;
}




