
#include "HelmholtzKernel.h"

int new_HelmholtzKernel(int size, double delta, double epsilon, double *zxlist, double *zylist, double *zzlist, \
	double *zxstarlist, double *zystarlist, double *zzstarlist, double *dist, double *gradx, double *grady, \
	double *gradz, double *curv, double *Jacobian, \
	double *PolyW, double *SineW, double *PolyResult, double *SineResult, \
	double **PolyKernelH, double **PolyKernelHimg, double **SineKernelH, double **SineKernelHimg)
{
	int counter;
	double zx, zy, zz, zstarx, zstary, zstarz, thisdist;
	double thisgradx, thisgrady, thisgradz, stargradx, stargrady, stargradz;
	double xminusy1, xminusy2, xminusy3;
	double starxi, starxj, staryi, staryj, starzi, starzj;
	double partialx, partialy, partialz, partialximg, partialyimg, partialzimg, partial, partialimg;

	double regfactor, regfactorimg, tau, threshold, regterm1 ,regterm2, regterm3, regterm4;

	tau = 0.1 * h;
	threshold = 0.01*h*h;
	
	regterm1 = 1.0/(4.0*PI*tau*radius);		//	1/8pi*tau(2/r)	//
	regterm2 = (-5.0*tau)/(256.0*pow(radius,3.0)*PI);	//	-(1/pi)*(5/512)*(2/r^3)*tau	//
	regterm3 = (-50.0*tau)/(1536.0*pow(radius,3.0)*PI);//	-(1/pi)*(25/1536)*(2/r^3)*tau	//
	regterm4 = (pow(WAVE,2.0)*tau)/(24.0*PI*radius);	//	Helmholtz 3D, (k^2/48)*(k1+k2)*tau	//

	if (INTERIOR_MODE==1)
		regfactor = regterm1 + regterm2 + regterm3 + regterm4;
	else
		regfactor = -1.0*(regterm1 + regterm2 + regterm3 + regterm4);

	regfactorimg = 0.0;



	counter = 0;
	for (int i = 0; i < N; i++)
	{
		zz = INT_L + double(i) * h;
	for (int j = 0; j < N; j++)
	{	
		zy = INT_L + double(j) * h;
	for (int k = 0; k < N; k++)
	{
		zx = INT_L + double(k) * h;
		thisdist = radius - sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
			
		if ( ( fabs(thisdist) > epsilon) || (fabs(thisdist) < delta) )
			continue;

		thisgradx = (Cx - zx) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
		thisgrady = (Cy - zy) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
		thisgradz = (Cz - zz) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
			
		zstarx = zx - thisdist * thisgradx;
		zstary = zy - thisdist * thisgrady;
		zstarz = zz - thisdist * thisgradz;

	stargradx = (Cx - zstarx) / sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz) );
	stargrady = (Cy - zstary) / sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz) );
	stargradz = (Cz - zstarz) / sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz) );

			
		zxlist[counter] = zx;
		zylist[counter] = zy;
		zzlist[counter] = zz;
		zxstarlist[counter] = zstarx;
		zystarlist[counter] = zstary;
		zzstarlist[counter] = zstarz;
		dist[counter] = thisdist;
		gradx[counter] = stargradx;
		grady[counter] = stargrady;
		gradz[counter] = stargradz;
		curv[counter] = 1./(radius - thisdist);
			
		//	Jacobian[counter] = 1. + thisdist * curv[counter];
		//	Jacobian[counter] = 1.;
		Jacobian[counter] = cal_J(J_M, zx, zy, zz);

		if (POLY_TEST == 1)
		{
			PolyW[counter] = PolyWeight(fabs(thisdist/epsilon), delta/epsilon)/(2.0*epsilon);
			PolyResult[counter] = h*h*h*Jacobian[counter] * PolyW[counter];
		}
		if (SINE_TEST == 1)
		{	
			SineW[counter] = SineWeight(fabs(thisdist/epsilon), delta/epsilon)/(2.0*epsilon);
			SineResult[counter] = h*h*h*Jacobian[counter] * SineW[counter];
		}

		counter++;
	}
	}
	}

	if (counter != size)
	{
		printf("Size different for new Kernel.\n");
		exit(0);
	}

	for (int i = 0; i < size; i++)
	{
		starxi = zxstarlist[i];
		staryi = zystarlist[i];
		starzi = zzstarlist[i];
		for (int j = 0; j < size; j++)
		{
			starxj = zxstarlist[j];
			staryj = zystarlist[j];
			starzj = zzstarlist[j];

			partialx = cal_partial(1, starxi, staryi, starzi, starxj, staryj, starzj);// x coordinate real	//
			partialy = cal_partial(2, starxi, staryi, starzi, starxj, staryj, starzj);// y coordinate real	//
			partialz = cal_partial(3, starxi, staryi, starzi, starxj, staryj, starzj);// z coordinate real	//
			partialximg = cal_partial(4, starxi, staryi, starzi, starxj, staryj, starzj);// x coordinate imag
			partialyimg = cal_partial(5, starxi, staryi, starzi, starxj, staryj, starzj);// y coordinate imag
			partialzimg = cal_partial(6, starxi, staryi, starzi, starxj, staryj, starzj);// z coordinate imag

			partial =  -1. * (partialx * gradx[i] + partialy * grady[i] + partialz * gradz[i]);
			partialimg = -1. * (partialximg * gradx[i] + partialyimg * grady[i] + partialzimg * gradz[i]);

			if ( ( (starxi-starxj)*(starxi-starxj) + (staryi-staryj)*(staryi-staryj) + \
				(starzi-starzj)*(starzi-starzj) ) < threshold )
			{
				partial = regfactor;
				partialimg = regfactorimg;
			}
//			else
//			{
//				partial = partial;
//				partialimg = partialimg;
//			}
			
			if (POLY_TEST == 1)
			{
				PolyKernelH[i][j] = partial * PolyResult[j];
				PolyKernelHimg[i][j] = partialimg * PolyResult[j];
				if (i == j)
					PolyKernelH[i][j] -= 0.5;			
			}
			if (SINE_TEST == 1)
			{
				SineKernelH[i][j] = partial * SineResult[j];
				SineKernelHimg[i][j] = partialimg * SineResult[j];
				if (i == j)
					SineKernelH[i][j] -= 0.5;
			}
		}
	}
	return 0;
}



int new_HelmholtzKernelCombo(int size, double delta, double epsilon, double *zxlist, double *zylist, double *zzlist, \
	double *zxstarlist, double *zystarlist, double *zzstarlist, double *dist, double *gradx, double *grady, \
	double *gradz, double *curv, double *Jacobian, \
	double *PolyW, double *SineW, double *PolyResult, double *SineResult, \
	double **PolyKernelH, double **PolyKernelHimg, double **SineKernelH, double **SineKernelHimg, double wavenum, \
	double eta)
{
	int counter, regcount;
	double zx, zy, zz, zstarx, zstary, zstarz, thisdist;
	double thisgradx, thisgrady, thisgradz, stargradx, stargrady, stargradz;
	double xminusy1, xminusy2, xminusy3, xminusynorm;
	double starxi, starxj, staryi, staryj, starzi, starzj;
	double partialx, partialy, partialz, partialximg, partialyimg, partialzimg, partial, partialimg;
	double Polysinglereal, Polysingleimg, Polydoublereal, Polydoubleimg, Polytempreal, Polytempimg;
	double Sinesinglereal, Sinesingleimg, Sinedoublereal, Sinedoubleimg, Sinetempreal, Sinetempimg;

	double x1, x2, x3, parameter, CosineValue, SineValue, commonterm1, commonterm2;
	double inner_pd1, inner_pd2, inner_pd3;
	double term1, term2, term3, term1R, term2R, term3R, term1I, term2I, term3I, term4R, term4I;
	static const double fourpi = 4.0 * PI;
//	double eta;

	double regfactor, regfactorimg, tau, threshold, regterm1, regterm2, regterm3, regterm4;

	tau = 0.01 * h;
	threshold = 0.0001*h*h;

	regterm1 = 1.0/(4.0*PI*tau*radius);		//	1/8pi*tau(2/r)	//
	regterm2 = (-5.0*tau)/(256.0*pow(radius,3.0)*PI);	//	-(1/pi)*(5/512)*(2/r^3)*tau	//
	regterm3 = (-50.0*tau)/(1536.0*pow(radius,3.0)*PI);//	-(1/pi)*(25/1536)*(2/r^3)*tau	//
	regterm4 = (pow(WAVE,2.0)*tau)/(24.0*PI*radius);	//	Helmholtz 3D, (k^2/48)*(k1+k2)*tau	//

//	if (INTERIOR_MODE==1)
//		regfactor = regterm1 + regterm2 + regterm3 + regterm4;
//	else
		regfactor = -1.0*(regterm1 + regterm2 + regterm3 + regterm4);

	regfactor = 0.0;
	regfactorimg = 0.0;


////////////////////////////////////////////////////////////
//	eta = 0.5;
////////////////////////////////////////////////////////////

	counter = 0;
	regcount = 0;
	for (int i = 0; i < N; i++)
	{
		zz = INT_L + double(i) * h;
	for (int j = 0; j < N; j++)
	{	
		zy = INT_L + double(j) * h;
	for (int k = 0; k < N; k++)
	{
		zx = INT_L + double(k) * h;

		thisdist = radius - sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
			
		if ( ( fabs(thisdist) > epsilon) || (fabs(thisdist) < delta) )
			continue;

//		thisgradx = (Cx - zx) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
//		thisgrady = (Cy - zy) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );
//		thisgradz = (Cz - zz) / sqrt( (zx-Cx)*(zx-Cx) + (zy-Cy)*(zy-Cy) + (zz-Cz)*(zz-Cz) );

		thisgradx = (Cx - zx) / (radius - thisdist);
		thisgrady = (Cy - zy) / (radius - thisdist);
		thisgradz = (Cz - zz) / (radius - thisdist);
			
		zstarx = zx - thisdist * thisgradx;
		zstary = zy - thisdist * thisgrady;
		zstarz = zz - thisdist * thisgradz;

//		stargradx = (Cx-zstarx)/sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz));
//		stargrady = (Cy-zstary)/sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz));
//		stargradz = (Cz-zstarz)/sqrt( (zstarx-Cx)*(zstarx-Cx) + (zstary-Cy)*(zstary-Cy) + (zstarz-Cz)*(zstarz-Cz));
		
		stargradx = (Cx - zstarx)/radius;
		stargrady = (Cy - zstary)/radius;
		stargradz = (Cz - zstarz)/radius;

		zxlist[counter] = zx;
		zylist[counter] = zy;
		zzlist[counter] = zz;
		zxstarlist[counter] = zstarx;
		zystarlist[counter] = zstary;
		zzstarlist[counter] = zstarz;
		dist[counter] = thisdist;
		gradx[counter] = stargradx;
		grady[counter] = stargrady;
		gradz[counter] = stargradz;
		curv[counter] = 1./(radius - thisdist);
			
//		Jacobian[counter] = 1. + thisdist * curv[counter];
//		Jacobian[counter] = 1.;
		Jacobian[counter] = cal_J(J_M, zx, zy, zz);

		if (POLY_TEST == 1)
		{
			PolyW[counter] = PolyWeight(fabs(thisdist/epsilon), delta/epsilon)/(2.0*epsilon);
			PolyResult[counter] = h*h*h*Jacobian[counter] * PolyW[counter];
		}
		if (SINE_TEST == 1)
		{
			SineW[counter] = SineWeight(fabs(thisdist/epsilon), delta/epsilon)/(2.0*epsilon);
			SineResult[counter] = h*h*h*Jacobian[counter] * SineW[counter];
		}
		counter++;
	}
	}
	}

	if (counter != size)
	{
		printf("Counter = %d, specified size = %d. Size different for new Kernel.\n", counter, size);
		printf("delta = %lf, epsilon = %lf.\n", delta, epsilon);
		exit(0);
	}

	for (int i = 0; i < size; i++)
	{
		starxi = zxstarlist[i];
		staryi = zystarlist[i];
		starzi = zzstarlist[i];
		for (int j = 0; j < size; j++)
		{
			
			starxj = zxstarlist[j];
			staryj = zystarlist[j];
			starzj = zzstarlist[j];

			//	SINGLE LAYER PART, dG(x*,y*)/dnx W(y) J(y) * h^2	//

//			if (0)
//			{
			partialx = cal_partial(1, starxi, staryi, starzi, starxj, staryj, starzj);// x coordinate real	//
			partialy = cal_partial(2, starxi, staryi, starzi, starxj, staryj, starzj);// y coordinate real	//
			partialz = cal_partial(3, starxi, staryi, starzi, starxj, staryj, starzj);// z coordinate real	//
			partialximg = cal_partial(4, starxi, staryi, starzi, starxj, staryj, starzj);// x coordinate imag
			partialyimg = cal_partial(5, starxi, staryi, starzi, starxj, staryj, starzj);// y coordinate imag
			partialzimg = cal_partial(6, starxi, staryi, starzi, starxj, staryj, starzj);// z coordinate imag
			
//			}
			//	ik/4 * H1(k|x-y|)/|x-y| [(x-y) dot nx] = ik/4 * (J1 + iY1)/|x-y| [inner_pd]	//
			
			partial =  -1. * (partialx * gradx[i] + partialy * grady[i] + partialz * gradz[i] );
			partialimg = -1. * (partialximg * gradx[i] + partialyimg * grady[i] + partialzimg * gradz[i] );

			if ( ( (starxi-starxj)*(starxi-starxj) + (staryi-staryj)*(staryi-staryj) + \
				(starzi-starzj)*(starzi-starzj)) < threshold )
			{
				regcount += 1;
				partial = regfactor;
				partialimg = regfactorimg;
			}
//			else
//			{
//				
//			}
//			else
//			{
//				partial = partial;
//				partialimg = partialimg;
//			}

			if (POLY_TEST == 1)
			{
				Polytempreal = partial * PolyResult[j];
				Polytempimg = partialimg * PolyResult[j];
				if (i == j)
					Polytempreal -= 0.5;
				//	-i * eta * dG(x,y*)/dnx		//
				Polysinglereal = eta * Polytempimg;
				Polysingleimg = -1. * eta * Polytempreal;
			}
			if (SINE_TEST == 1)
			{
				Sinetempreal = partial * SineResult[j];
				Sinetempimg = partialimg * SineResult[j];
				if (i == j)
					Sinetempreal -= 0.5;
				Sinesinglereal = eta * Sinetempimg;
				Sinesingleimg = -1. * eta * Sinetempreal;
			}

			//	DOUBLE LAYER PART, d^2G(x(d(y)), y*)/dnxdny W(y) J(y) h^2	//

			//	x = x(d(y)) = x* + |d(y)| nx	, only outside points	//
			x1 = starxi + fabs(dist[j]) * gradx[i];
			x2 = staryi + fabs(dist[j]) * grady[i];
			x3 = starzi + fabs(dist[j]) * gradz[i];

			xminusy1 = x1 - starxj;
			xminusy2 = x2 - staryj;
			xminusy3 = x3 - starzj;
			xminusynorm = sqrt( xminusy1 * xminusy1 + xminusy2 * xminusy2 + xminusy3 * xminusy3);
			parameter = wavenum * xminusynorm;


/////////////////////////////////	this part is/might be 3D specific	///////////////////////////
//
			inner_pd1 = gradx[i] * gradx[j] + grady[i] * grady[j] + gradz[i] * gradz[j];
			inner_pd2 = xminusy1 * gradx[i] + xminusy2 * grady[i] + xminusy3 * gradz[i];
			inner_pd3 = xminusy1 * gradx[j] + xminusy2 * grady[j] + xminusy3 * gradz[j];

			commonterm1 = inner_pd1 / xminusynorm;
			commonterm2 = inner_pd2 * inner_pd3 / ( xminusynorm*xminusynorm );

			CosineValue = cos(parameter)/xminusynorm;
			SineValue = sin(parameter)/xminusynorm;

			//	term1 = e^ik|x-y| /|x-y|^2 * (ik - 1/|x-y|) * (nx dot ny)		//
			//	-1(cos(k|x-y|)/|x-y|^2 + k * sin(k|x-y|)/|x-y|) (nx dot ny)/|x-y|	//
			term1R = -1. * ( CosineValue/xminusynorm + wavenum * SineValue ) * commonterm1;
			//	(k * cos(k|x-y|)/|x-y| - sin(k|x-y|)/|x-y|^2) (nx dot ny)/|x-y|
			term1I = ( wavenum * CosineValue - SineValue/xminusynorm ) * commonterm1;
			//	term2 = -k^2 e^ik|x-y| /|x-y|^3	* (nx dot (x-y)) (ny dot (x-y))		//
			//	-k^2 cos(k|x-y|)/|x-y| * (inner_pd2 * inner_pd3)/ |x-y|^2		//
			term2R = -1. * wavenum * wavenum * CosineValue * commonterm2;
			//	-k^2 sin(k|x-y|)/|x-y| * (inner_pd2 * inner_pd3)/ |x-y|^2		//
			term2I = -1. * wavenum * wavenum * SineValue * commonterm2;
			//	term3 = -3ik * e^ik|x-y|/|x-y|^4 * (nx dot (x-y)) (ny dot (x-y))	//
			//	3ksin(k|x-y|)/|x-y| * 1/|x-y| * (inner_pd2 * inner_pd3)/|x-y|^2		//
			term3R = 3. * wavenum * SineValue * commonterm2 / xminusynorm;			
			//	-3k cos(k|x-y|)/|x-y| * 1/|x-y| * (inner_pd2 * inner_pd3)/|x-y|^2	//
			term3I = -3. * wavenum * CosineValue * commonterm2 / xminusynorm;
			//	term4 = 3e^ik|x-y|/|x-y|^5 * (inner_pd2 * inner_pd3)			//
			//	3cos(k|x-y|)/|x-y| * 1/|x-y|^2 * (inner_pd2 * inner_pd3)/|x-y|^2	//
			term4R = 3. * CosineValue * commonterm2 / (xminusynorm*xminusynorm);		
			//	3sin(k|x-y|)/|x-y| * 1/|x-y|^2 * (inner_pd2 * inner)pd3)/|x-y|^2	//
			term4I = 3. * SineValue * commonterm2 / (xminusynorm * xminusynorm);

/////////////////////////////////////////////////////////////////////////////////////////////////////////////

			if (POLY_TEST == 1)
			{
				Polydoublereal = PolyResult[j] * (term1R + term2R + term3R + term4R)/fourpi;
				Polydoubleimg = PolyResult[j] * (term1I + term2I + term3I + term4I)/fourpi;
				PolyKernelH[i][j] = Polysinglereal + Polydoublereal;
				PolyKernelHimg[i][j] = Polysingleimg + Polydoubleimg;
			}
			if (SINE_TEST == 1)
			{
				Sinedoublereal = SineResult[j] * (term1R + term2R + term3R + term4R)/fourpi;
				Sinedoubleimg = SineResult[j] * (term1I + term2I + term3I + term4I)/fourpi;
				SineKernelH[i][j] = Sinesinglereal + Sinedoublereal;
				SineKernelHimg[i][j] = Sinesingleimg + Sinedoubleimg;
			}

//			PolyKernelH[i][j] = Polysinglereal;
//			PolyKernelHimg[i][j] = Polysingleimg;
//			SineKernelH[i][j] = Sinesinglereal;
//			SineKernelHimg[i][j] = Sinesingleimg;

		}
	}
	printf("Regcount = %d.\n", regcount);
	return 0;
}
