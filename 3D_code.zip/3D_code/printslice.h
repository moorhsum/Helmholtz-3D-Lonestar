
#ifndef PRINTSLICE_H_DEFINED
#define PRINTSLICE_H_DEFINED

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "PDE.h"
#include "functions.h"
#include "tools.h"
#include "frame.h"
#include "PDE.h"
#include "constants.h"

#define FORCING 1	//	force to print the interior as irrelevant		//

extern double N;
extern double h;
extern double N2;
extern double h2;
extern double WAVE;
extern double XSLICE, YSLICE, ZSLICE;

int print_apruz(int size);
int print_apruy(int size);
int print_aprux(int size);

#endif
