
#ifndef PDE_H_DEFINED
#define PDE_H_DEFINED


#define LAPLACE 0
#define DIRICHLET 0
#define INTERIOR_MODE 0
#define FACTOR 2.0	//	the factor for epsilon = factor * h	//
#define REG_MODE 1	//	to use regularized partial or not	//
#define POLY_TEST 0	//	test polynomial weight
#define SINE_TEST 1	//	test sine weight


#endif
